package com.camilo.nuevospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NuevoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(NuevoSpringApplication.class, args);
	}

}
